import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-multiple-question',
  templateUrl: './multiple-question.component.html',
  styleUrl: './multiple-question.component.css',
  standalone:true,
  imports:[CommonModule,ReactiveFormsModule,FormsModule],
  exportAs:"app-multiple-question"
})
export class MultipleQuestionComponent {

@Input()question: any

}
