import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-free-text-question',
  templateUrl: './free-text-question.component.html',
  styleUrl: './free-text-question.component.css',
  standalone:true,
  imports:[CommonModule,ReactiveFormsModule,FormsModule],
  exportAs:"app-free-text-question"
})
export class FreeTextQuestionComponent {
@Input()question: any
}
