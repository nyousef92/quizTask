import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-boolean-question',
  templateUrl: './boolean-question.component.html',
  styleUrl: './boolean-question.component.css',
   standalone:true,
    imports:[CommonModule,ReactiveFormsModule,FormsModule],
    exportAs:"app-boolean-question"
})
export class BooleanQuestionComponent{
@Input()question: any

}
