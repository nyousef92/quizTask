import { FormControl } from '@angular/forms';

type QuestionType = 'multiple' | 'freetext' | 'boolean';
type DifficultyLevel = 'easy' | 'medium' | 'hard';

export interface question{
    category:string,
      type:  QuestionType ,
      difficulty:DifficultyLevel ,
      question:  string ,
      correct_answer:  string ,
      incorrect_answers?: string[],
      control?:FormControl
}

export const LEVELS_MAP = new Map<DifficultyLevel, number>([
    ['hard', 5],
    ['medium', 3],
    ['easy', 1],
  ]);
