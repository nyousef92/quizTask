import { FormControl } from '@angular/forms';

import {
    BooleanQuestionComponent
} from '../question-types/boolean-question/boolean-question.component';
import {
    FreeTextQuestionComponent
} from '../question-types/free-text-question/free-text-question.component';
import {
    MultipleQuestionComponent
} from '../question-types/multiple-question/multiple-question.component';

type QuestionType = 'multiple' | 'freetext' | 'boolean';
type DifficultyLevel = 'easy' | 'medium' | 'hard';
type QuestionCategory = 'History' | 'Geology' | 'Science' | 'General Knowledge';

export interface question {
  category: QuestionCategory;
  type: QuestionType;
  difficulty: DifficultyLevel;
  question: string;
  correct_answer: string;
  incorrect_answers?: string[];
  control?: FormControl;
}

export const LEVELS_MAP = new Map<DifficultyLevel, number>([
  ['hard', 5],
  ['medium', 3],
  ['easy', 1],
]);

export const componentMap = new Map<QuestionType, any>([
  ['multiple', MultipleQuestionComponent],
  ['boolean', BooleanQuestionComponent],
  ['freetext', FreeTextQuestionComponent],
]);
