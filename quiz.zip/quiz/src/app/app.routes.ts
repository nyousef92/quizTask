import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path:'',
        loadChildren:()=>import('../questions-journy/questions-journy.module').then(m=>m.QuestionsJournyModule)
    }
];
