import {
    Component, ComponentFactoryResolver, Input, OnChanges, SimpleChanges, ViewChild,
    ViewContainerRef
} from '@angular/core';

import {
    BooleanQuestionComponent
} from '../../question-types/boolean-question/boolean-question.component';
import {
    FreeTextQuestionComponent
} from '../../question-types/free-text-question/free-text-question.component';
import {
    MultipleQuestionComponent
} from '../../question-types/multiple-question/multiple-question.component';

@Component({
  selector: 'app-question-item',
  standalone: true,
  imports: [],
  templateUrl: './question-item.component.html',
  styleUrl: './question-item.component.css',
})
export class QuestionItemComponent implements OnChanges {
  readonly map = [
    {
      type: 'multiple',
      comp: MultipleQuestionComponent,
    },
    {
      type: 'boolean',
      comp: BooleanQuestionComponent,
    },
    {
      type: 'freetext',
      comp: FreeTextQuestionComponent,
    },
  ];
  @Input() question:
    | {
        category: string;
        type: string;
        difficulty: string;
        question: string;
        correct_answer: string;
        incorrect_answers: string[];
      }
    | undefined;

  @ViewChild('dynamicContainer', { read: ViewContainerRef, static: true })
  container!: ViewContainerRef;
  constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.loadComponent(this.question?.type || '');
  }

  loadComponent(questionType: string) {
    const comp = this.map.find((i) => i.type === this.question?.type)?.comp || null;

    if (comp) {
      const componentFactory =
        this.componentFactoryResolver.resolveComponentFactory(
          comp || MultipleQuestionComponent
        );

      const componentRef = this.container.createComponent(componentFactory);
      componentRef.instance['question'] = this.question;
    }
  }
}
