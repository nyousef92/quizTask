import {
    Component, ComponentFactoryResolver, Input, OnChanges, SimpleChanges, ViewChild,
    ViewContainerRef
} from '@angular/core';

import {
    MultipleQuestionComponent
} from '../../question-types/multiple-question/multiple-question.component';

@Component({
  selector: 'app-question-item',
  standalone: true,
  imports: [],
  templateUrl: './question-item.component.html',
  styleUrl: './question-item.component.css',
})
export class QuestionItemComponent implements OnChanges {
 
  @Input() question:
    | {
        category: string;
        type: string;
        difficulty: string;
        question: string;
        correct_answer: string;
        incorrect_answers: string[];
      }
    | undefined;

  @ViewChild('dynamicContainer', { read: ViewContainerRef, static: true })
  container!: ViewContainerRef;
  componentMap: any;
  constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.loadComponent(this.question?.type || '');
  }

  loadComponent(questionType: string) {
    const comp = this.componentMap.get(this.question?.type)||null
   

    if (comp) {
      const componentFactory =
        this.componentFactoryResolver.resolveComponentFactory(
          comp || MultipleQuestionComponent
        );

      const componentRef = this.container.createComponent(componentFactory);
      componentRef.instance['question'] = this.question;
    }
  }
}
