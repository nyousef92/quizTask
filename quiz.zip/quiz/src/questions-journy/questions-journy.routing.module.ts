import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { QuestionsService } from './services/questions.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
  ],
  providers:[QuestionsService]
})
export class QuestionsJournyModule { }
