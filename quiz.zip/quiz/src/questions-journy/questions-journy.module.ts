
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { QuetionsContainerComponent } from './quetions-container/quetions-container.component';
import { QuestionsService } from './services/questions.service';

const routes:Routes=[{
path:'',
component:QuetionsContainerComponent
}];

  @NgModule({
    imports: [RouterModule.forChild(routes),ReactiveFormsModule,CommonModule],
    exports: [RouterModule],
    providers:[QuestionsService],
    declarations:[]
})
export class QuestionsJournyModule { }
