import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import {
    FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators
} from '@angular/forms';

import { question } from '../../inteface/iquestion';
import { QuestionItemComponent } from '../question-item/question-item.component';
import { QuestionsService } from '../services/questions.service';
import { requiredAnswerValidator } from '../validators/validator';

@Component({
  selector: 'app-quetions-container',
  templateUrl: './quetions-container.component.html',
  styleUrl: './quetions-container.component.css',
  imports: [ReactiveFormsModule, CommonModule, QuestionItemComponent],
  standalone: true,
})
export class QuetionsContainerComponent implements OnInit {
  categories: any;
  categoriesForm: any;
  activeQuestionIndex: number = 0;

  @ViewChild('dynamicContainer', { read: ViewContainerRef, static: true })
  container!: ViewContainerRef;

  questionList: any;
  questionForm: FormGroup | undefined;
  score: number = 0;

  constructor(
    public QuestionsService: QuestionsService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.QuestionsService.loadQuestionCategories().subscribe({
      next: (data) => {
        this.categories = Array.from(data);
        this.categoriesForm = this.formBuilder.group({
          type: ['', Validators.required],
        });
      },
    });

    this.subscribeToQuestionType();
    this.subscribeToListChanges();
  }

  subscribeToListChanges() {
    this.QuestionsService.activeQuestionList.subscribe((list: question[]) => {
      this.questionList = list;
      this.questionList = list;
      this.appendControls();
    });
  }

  subscribeToQuestionType() {
    this.categoriesForm.controls['type'].valueChanges.subscribe(
      (questionCategory: any) => {
        this.score = 0;
        this.QuestionsService.getQuestionsByCategory(questionCategory);
      }
    );
  }

  appendControls() {
    this.questionForm = this.formBuilder.group({});
    for (let index = 0; index < this.questionList.length; index++) {
      const control = new FormControl('', [
        requiredAnswerValidator(this.questionList[index].correct_answer),
      ]);
      this.questionForm.addControl(`queston${index}`, control);
      this.questionList[index].control = control;
    }
  }

  nextQuestion() {
    debugger;
    if (
      this.questionList[this.activeQuestionIndex].control.value &&
      this.activeQuestionIndex < this.questionList.length
    ) {
      this.activeQuestionIndex = this.activeQuestionIndex + 1;
    }
  }
  previousQuestion() {
    this.activeQuestionIndex =
      this.activeQuestionIndex !== 0 ? this.activeQuestionIndex - 1 : 0;
  }

  done() {
    // const areAllQuestionsAnswered=Object.values(this.questionForm.controls).every(
    //   (control ) => control?.value || null !== null && control?.value !== undefined && control?.value !== ''
    // )

    let score = 0;

    for (let item of this.questionList) {
      if (item.control.valid) {
        score =
          score +
          (this.QuestionsService.getLevelsMap().get(item.difficulty) || 0);
      }
    }
    this.score = score;
  }
}
