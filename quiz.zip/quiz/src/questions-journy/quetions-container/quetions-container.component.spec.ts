import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuetionsContainerComponent } from './quetions-container.component';

describe('QuetionsContainerComponent', () => {
  let component: QuetionsContainerComponent;
  let fixture: ComponentFixture<QuetionsContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuetionsContainerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuetionsContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
