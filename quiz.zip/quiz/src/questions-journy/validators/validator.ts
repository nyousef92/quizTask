import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function requiredAnswerValidator(requiredAnswer: any): ValidatorFn {

    return (control: AbstractControl): ValidationErrors | null => {
        const value = control.value;
        return value === requiredAnswer
          ? null
          : { requiredAnswer: { requiredValue: requiredAnswer, actualValue: value } };
      };
}